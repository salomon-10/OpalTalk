<?php
session_start();
require 'config.php';

// Simule un utilisateur connecté temporairement :
if (!isset($_SESSION['username'])) {
    $_SESSION['username'] = 'testuser'; // remplace par un vrai nom d'utilisateur de ta BDD
}

echo "<h2>Historique des messages</h2>";
echo "<div style='background:#eee; padding:10px;'>";

$stmt = $pdo->query("SELECT messages.*, users.username FROM messages JOIN users ON messages.sender_id = users.id ORDER BY created_at ASC");
while ($row = $stmt->fetch()) {
    $me = ($_SESSION['username'] === $row['username']) ? ' (Moi)' : '';
    echo "<p><strong>{$row['username']}{$me}</strong> : " . htmlspecialchars($row['message']) . "</p>";
}

echo "</div>";
?>
